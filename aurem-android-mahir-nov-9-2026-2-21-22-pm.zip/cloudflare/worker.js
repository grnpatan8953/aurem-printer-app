/**
 * AUREM AI Board Studio — Production Cloudflare Worker
 * Model: @cf/black-forest-labs/flux-2-klein-4b
 * Binding: AI
 *
 * Features:
 * - Mandatory server-side Google OAuth ID Token verification (aud, iss, exp, sub)
 * - Strict per-user daily quota enforcement (10 generations/user/day) via KV or durable storage
 * - Support for up to 4 reference images (image_0 to image_3) for FLUX.2 Klein 4B image-to-image/reference generation
 * - Robust output validation (JPEG magic bytes verification, safe binary response handling)
 * - Full CORS support
 */

const EXPECTED_CLIENT_ID = "119004603451-bnmu5tolkta41d5fgas0geueekpmf8bj.apps.googleusercontent.com";
const DAILY_LIMIT_PER_USER = 10;

function getCorsHeaders() {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Max-Age": "86400",
  };
}

async function verifyGoogleToken(idToken) {
  if (!idToken || typeof idToken !== "string" || idToken.length < 20) {
    return { valid: false, error: "Missing or malformed Google ID token" };
  }

  try {
    const res = await fetch(`https://oauth2.googleapis.com/tokeninfo?id_token=${encodeURIComponent(idToken)}`, {
      headers: { "Accept": "application/json" }
    });

    if (!res.ok) {
      return { valid: false, error: "Google token verification failed (HTTP " + res.status + ")" };
    }

    const payload = await res.json();

    // Verify audience matches AUREM OAuth Web Client ID or project number
    if (payload.aud !== EXPECTED_CLIENT_ID && (!payload.aud || !payload.aud.startsWith("119004603451"))) {
      return { valid: false, error: "Token audience mismatch for AUREM" };
    }

    // Verify issuer
    if (payload.iss !== "accounts.google.com" && payload.iss !== "https://accounts.google.com") {
      return { valid: false, error: "Invalid token issuer" };
    }

    // Verify expiration
    const nowSec = Math.floor(Date.now() / 1000);
    if (payload.exp && Number(payload.exp) < nowSec) {
      return { valid: false, error: "Google ID token has expired" };
    }

    const today = new Date().toISOString().slice(0, 10);
    const userId = payload.sub || payload.email || "unknown";

    return {
      valid: true,
      userId,
      email: payload.email || "",
      name: payload.name || "",
      dayKey: `aurem:quota:${today}:${userId}`
    };
  } catch (err) {
    return { valid: false, error: "Token verification network error: " + err.message };
  }
}

async function checkAndIncrementUsage(env, dayKey) {
  if (!env.AI_USAGE) {
    throw Error("Cloudflare KV binding 'AI_USAGE' is required for durable quota enforcement.");
  }
  const currentVal = await env.AI_USAGE.get(dayKey);
  const current = currentVal ? parseInt(currentVal, 10) : 0;
  if (current >= DAILY_LIMIT_PER_USER) {
    return { allowed: false, count: current };
  }
  await env.AI_USAGE.put(dayKey, (current + 1).toString(), { expirationTtl: 86400 });
  return { allowed: true, count: current + 1 };
}

export default {
  async fetch(request, env) {
    const cors = getCorsHeaders();

    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: cors });
    }

    if (request.method === "GET") {
      return new Response(
        JSON.stringify({
          status: "ok",
          service: "AUREM AI Board Studio",
          model: "@cf/black-forest-labs/flux-2-klein-4b",
          freeTierQuota: `${DAILY_LIMIT_PER_USER} generations/day`,
          timestamp: new Date().toISOString()
        }),
        { headers: { "Content-Type": "application/json", ...cors } }
      );
    }

    if (request.method !== "POST") {
      return new Response(JSON.stringify({ error: "Method Not Allowed" }), {
        status: 405,
        headers: { "Content-Type": "application/json", ...cors }
      });
    }

    // MANDATORY AUTHENTICATION: Reject every unauthenticated request
    const authHeader = request.headers.get("Authorization") || "";
    const idToken = authHeader.replace(/^Bearer\s+/i, "").trim();

    if (!idToken) {
      return new Response(
        JSON.stringify({ error: "Authentication required. Google ID token missing." }),
        { status: 401, headers: { "Content-Type": "application/json", ...cors } }
      );
    }

    const authResult = await verifyGoogleToken(idToken);
    if (!authResult.valid) {
      return new Response(
        JSON.stringify({ error: authResult.error }),
        { status: 401, headers: { "Content-Type": "application/json", ...cors } }
      );
    }

    const user = authResult;

    // Enforce durable daily free usage quota
    try {
      const usage = await checkAndIncrementUsage(env, user.dayKey);
      if (!usage.allowed) {
        return new Response(
          JSON.stringify({
            error: `Daily free quota reached (${DAILY_LIMIT_PER_USER} generations/day). Quota resets tomorrow.`,
            quotaReached: true
          }),
          { status: 429, headers: { "Content-Type": "application/json", ...cors } }
        );
      }
    } catch (quotaErr) {
      return new Response(
        JSON.stringify({ error: "Quota enforcement error: " + quotaErr.message }),
        { status: 500, headers: { "Content-Type": "application/json", ...cors } }
      );
    }

    // Parse multipart form data
    let prompt = "";
    let width = 1024;
    let height = 1024;
    const images = [];

    try {
      const contentType = request.headers.get("content-type") || "";
      if (contentType.includes("multipart/form-data")) {
        const formData = await request.formData();
        prompt = (formData.get("prompt") || "").toString().trim();
        const w = parseInt(formData.get("width"), 10);
        const h = parseInt(formData.get("height"), 10);
        if (!isNaN(w) && w > 0) width = w;
        if (!isNaN(h) && h > 0) height = h;

        // Extract up to 4 reference images (image_0 to image_3)
        for (let i = 0; i < 4; i++) {
          const imgField = formData.get(`image_${i}`) || formData.get(`image${i}`);
          if (imgField && typeof imgField === "object") {
            const arrayBuffer = await imgField.arrayBuffer();
            images.push([...new Uint8Array(arrayBuffer)]);
          }
        }
      } else {
        const json = await request.json().catch(() => ({}));
        prompt = (json.prompt || "").toString().trim();
        if (json.width) width = json.width;
        if (json.height) height = json.height;
      }
    } catch (parseErr) {
      return new Response(
        JSON.stringify({ error: "Failed to parse request payload: " + parseErr.message }),
        { status: 400, headers: { "Content-Type": "application/json", ...cors } }
      );
    }

    if (!prompt || prompt.length < 3) {
      return new Response(
        JSON.stringify({ error: "Missing or invalid 'prompt' parameter" }),
        { status: 400, headers: { "Content-Type": "application/json", ...cors } }
      );
    }

    try {
      // Prepare FLUX.2 Klein 4B input payload
      const aiInput = {
        prompt,
        width,
        height
      };

      if (images.length > 0) {
        // FLUX.2 Klein 4B supports image references
        aiInput.image = images[0]; // primary reference
        if (images.length > 1) aiInput.images = images;
      }

      const aiResponse = await env.AI.run("@cf/black-forest-labs/flux-2-klein-4b", aiInput);

      let jpegBytes = null;
      if (aiResponse instanceof Uint8Array || aiResponse instanceof ArrayBuffer) {
        jpegBytes = new Uint8Array(aiResponse);
      } else if (aiResponse && typeof aiResponse === "object") {
        if (aiResponse.image && typeof aiResponse.image === "string") {
          // Base64 string response
          const b64 = aiResponse.image.replace(/^data:image\/[a-z]+;base64,/, "");
          const bin = atob(b64);
          jpegBytes = new Uint8Array(bin.length);
          for (let i = 0; i < bin.length; i++) jpegBytes[i] = bin.charCodeAt(i);
        } else if (aiResponse instanceof ReadableStream) {
          const buf = await new Response(aiResponse).arrayBuffer();
          jpegBytes = new Uint8Array(buf);
        }
      }

      if (!jpegBytes || jpegBytes.length < 100) {
        throw Error("AI model returned invalid or empty image output");
      }

      // Verify JPEG magic bytes (FF D8 FF)
      if (jpegBytes[0] !== 0xff || jpegBytes[1] !== 0xd8 || jpegBytes[2] !== 0xff) {
        // If it's JSON error string
        try {
          const text = new TextDecoder().decode(jpegBytes);
          const json = JSON.parse(text);
          if (json.error) throw Error(json.error);
        } catch (_) {}
        throw Error("Generated output is not a valid JPEG image stream");
      }

      return new Response(jpegBytes, {
        headers: {
          "Content-Type": "image/jpeg",
          "Cache-Control": "public, max-age=86400",
          ...cors
        }
      });
    } catch (err) {
      return new Response(
        JSON.stringify({ error: "Cloudflare AI generation failed: " + err.message }),
        { status: 500, headers: { "Content-Type": "application/json", ...cors } }
      );
    }
  }
};

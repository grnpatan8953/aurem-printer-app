# AUREM • Offline Floor-Walk Board Management

Curated by Mahir, **AUREM** is an offline-first Android application designed for retail floor walks, barcode management, board printing, and audit operations.

## Key Features

- **CORE & NON-CORE Board Studio**: Multi-size board preparation (1/20, 1/9, 1/8, 1/4, 1/3, 1/2, 1/1 Full A4) with automatic formatting and Mahir's 1/20 offer styling (B1G1 / B1G2).
- **Barcode & Digits Scanner**: Built-in camera barcode and ML Kit text recognition for EAN-13 and numerical codes.
- **Stock & Master Import**: High-performance local parser for REG-STAT, ITEM_EANS, Focus, and Permanent lists (CSV, TSV, TXT, XLSX).
- **Permanent EAN Library**: Persistent local alias mapping keyed by Bansal CODE with conflict prevention and JSON backup/restore.
- **A4 Sheet Preview & Printing**: Live sheet preview with Page Saver mode, standard layout, paper color selection (White / Yellow), and direct Android PDF generation / system print dispatch.
- **Floor Walk Sessions**: Complete session tracking, autosave, and walk history.

## Technical Architecture

- **Platform**: Android SDK 36 (minSdk 26, targetSdk 34)
- **Language**: Kotlin 2.2.10
- **Build System**: Gradle 9.3.1 with Android Gradle Plugin (AGP) 9.1.1
- **UI & Runtime**: Modern edge-to-edge Android container with Jetpack libraries, Material Components, ML Kit Text Recognition, and hardware-accelerated WebView asset loader.

/* Workbook reader for modern .xlsx: parses every worksheet; no CDN or network access. */
const decoder=new TextDecoder('utf-8');
export async function unzip(buffer){
 const bytes=new Uint8Array(buffer),view=new DataView(buffer);let end=-1;
 for(let i=bytes.length-22;i>=Math.max(0,bytes.length-65557);i--)if(view.getUint32(i,true)===0x06054b50){end=i;break}
 if(end<0)throw Error('Not a valid XLSX file.');
 const total=view.getUint16(end+10,true),start=view.getUint32(end+16,true),files={};let cur=start;
 for(let i=0;i<total;i++){
  if(view.getUint32(cur,true)!==0x02014b50)throw Error('Invalid XLSX archive index.');
  const method=view.getUint16(cur+10,true),size=view.getUint32(cur+20,true),nl=view.getUint16(cur+28,true),xl=view.getUint16(cur+30,true),cl=view.getUint16(cur+32,true),offset=view.getUint32(cur+42,true),name=decoder.decode(bytes.subarray(cur+46,cur+46+nl));cur+=46+nl+xl+cl;
  if(!(/^(xl\/worksheets\/sheet\d+\.xml|xl\/sharedStrings\.xml|xl\/styles\.xml|xl\/workbook\.xml|xl\/_rels\/workbook\.xml\.rels)$/.test(name)))continue;
  if(view.getUint32(offset,true)!==0x04034b50)throw Error('Corrupt XLSX entry.');
  const lf=view.getUint16(offset+26,true),le=view.getUint16(offset+28,true),data=bytes.slice(offset+30+lf+le,offset+30+lf+le+size);
  if(method===0)files[name]=decoder.decode(data);
  else if(method===8){if(!globalThis.DecompressionStream)throw Error('This browser cannot open compressed Excel files. Use modern Chrome or Edge.');
   const raw=await new Response(new Blob([data]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).arrayBuffer();files[name]=decoder.decode(new Uint8Array(raw));}
  else throw Error('Unsupported XLSX compression method: '+method);
 }
 return files;
}
function dom(s){const doc=new DOMParser().parseFromString(s,'application/xml');if(doc.getElementsByTagName('parsererror').length)throw Error('Excel XML cannot be parsed.');return doc}
const tag=(root,local)=>Array.from(root.childNodes).find(x=>x.nodeType===1&&x.localName===local);
const tags=(root,local)=>Array.from(root.childNodes).filter(x=>x.nodeType===1&&x.localName===local);
function expandNumericText(raw){const m=/^([+-]?)(\d+)(?:\.(\d*))?(?:[eE]([+-]?\d+))?$/.exec(String(raw));if(!m)return String(raw);const sign=m[1],whole=m[2],frac=m[3]||'',exp=Number(m[4]||0);if(!Number.isInteger(exp)||Math.abs(exp)>100)return String(raw);const digits=whole+frac,point=whole.length+exp;if(point<=0)return sign+'0.'+'0'.repeat(-point)+digits;if(point>=digits.length)return sign+digits+'0'.repeat(point-digits.length);return sign+digits.slice(0,point)+'.'+digits.slice(point);}
function value(c,shared,formats){const t=c.getAttribute('t');if(t==='inlineStr')return tag(c,'is')?.textContent||'';let raw=tag(c,'v')?.textContent||'';if(t==='s')return String(shared[Number(raw)]??'').trim();if(t==='str')return String(raw).trim();raw=expandNumericText(raw);const style=Number(c.getAttribute('s')||0),format=(formats[style]||'').split(';')[0];if(/^-?\d+$/.test(raw)&&/^0{6,}$/.test(format)){const negative=raw.startsWith('-'),digits=negative?raw.slice(1):raw;raw=(negative?'-':'')+digits.padStart(format.length,'0');}return String(raw).trim();}
function readNumberFormats(source){if(!source)return[];const doc=dom(source),custom=new Map();const fmts=doc.getElementsByTagName('numFmt');for(const f of fmts)custom.set(Number(f.getAttribute('numFmtId')),f.getAttribute('formatCode')||'');const xfs=doc.getElementsByTagName('cellXfs')[0];return xfs?Array.from(xfs.getElementsByTagName('xf')).map(x=>custom.get(Number(x.getAttribute('numFmtId')))||''):[];}function readSheet(source,shared,formats){
 const doc=dom(source),rows=[];for(const r of doc.getElementsByTagName('row')){
  const cells=[];let next=0;
  for(const c of tags(r,'c')){
   const ref=c.getAttribute('r')||'',letters=/^[A-Z]+/i.exec(ref)?.[0]||'';let n=0;
   if(letters){for(const l of letters.toUpperCase())n=n*26+l.charCodeAt(0)-64;n--;}else n=next;
   next=n+1;if(n>250)continue;cells[n]=value(c,shared,formats);
  }
  if(cells.some(x=>x!==undefined&&x!==''))rows.push(Array.from({length:cells.length},(_,i)=>cells[i]??''));
 }
 return rows;
}
export async function parseXlsxAll(file){
 const files=await unzip(await file.arrayBuffer());const names=[];
 if(files['xl/workbook.xml']){
  const wb=dom(files['xl/workbook.xml']);for(const n of wb.getElementsByTagName('sheet'))names.push(n.getAttribute('name')||'');
 }
 const formats=readNumberFormats(files['xl/styles.xml']);const shared=[];
 if(files['xl/sharedStrings.xml']){
  const ss=dom(files['xl/sharedStrings.xml']);for(const si of ss.getElementsByTagName('si'))shared.push(Array.from(si.getElementsByTagName('t')).map(t=>t.textContent||'').join(''));
 }
 const entries=Object.keys(files).filter(x=>/^xl\/worksheets\/sheet\d+\.xml$/.test(x)).sort((a,b)=>Number(a.match(/sheet(\d+)\.xml/)[1])-Number(b.match(/sheet(\d+)\.xml/)[1]));
 if(!entries.length)throw Error('Workbook contains no readable worksheets.');
 return entries.map((path,i)=>({name:names[i]||`Sheet ${i+1}`,rows:readSheet(files[path],shared,formats)}));
}
export async function parseXlsx(file){return(await parseXlsxAll(file))[0].rows}

/* Password-gated SELECTIVE clear, scoped to explicit IndexedDB categories. */
const A$=id=>document.getElementById(id);
const DB='AUREM_Offline_Data';
async function dbopen(){return await new Promise((yes,no)=>{const r=indexedDB.open(DB,1);r.onupgradeneeded=()=>r.result.createObjectStore('data');r.onsuccess=()=>yes(r.result);r.onerror=()=>no(r.error)})}
async function access(fn){const db=await dbopen();try{return await fn(db)}finally{db.close()}}
async function read(key){return access(db=>new Promise((yes,no)=>{const r=db.transaction('data').objectStore('data').get(key);r.onsuccess=()=>yes(r.result);r.onerror=()=>no(r.error)}))}
async function writeMany(entries){return access(db=>new Promise((yes,no)=>{const tx=db.transaction('data','readwrite');for(const [k,v] of entries)tx.objectStore('data').put(v,k);tx.oncomplete=yes;tx.onerror=()=>no(tx.error)}))}
const encode=s=>new TextEncoder().encode(s);
async function derive(password,salt){const cryptoKey=await crypto.subtle.importKey('raw',encode(password),'PBKDF2',false,['deriveBits']);const bytes=await crypto.subtle.deriveBits({name:'PBKDF2',salt,iterations:210000,hash:'SHA-256'},cryptoKey,256);return [...new Uint8Array(bytes)].map(x=>x.toString(16).padStart(2,'0')).join('')}
export function mountAdmin(){const holder=A$('adminMount');if(!holder)return;
 holder.innerHTML=`<section class="card" style="border-color:#6f4852"><h2>🔐 Admin — Selective Clear Data</h2>
 <p class="quiet">First set YOUR password. Then choose exactly which categories to clear. No default password exists.</p>
 <div id="adminSetupBox"><label class="field">Create new administrator password (10+ characters)<input id="adminSetupPass" type="password" autocomplete="new-password" placeholder="Choose your own password"></label><label class="field">Confirm administrator password<input id="adminSetupConfirm" type="password" autocomplete="new-password" placeholder="Enter the same password again"></label><button id="adminCreate" class="action primary">Set My Password</button></div>
 <div class="input-grid" id="adminCategories"><label><input type="checkbox" value="core"> CORE saved boards / scans</label><label><input type="checkbox" value="noncore"> NON-CORE saved boards / scans</label><label><input type="checkbox" value="custom"> CUSTOM saved boards (Round / Replica / AI / Loose Grocery)</label><label><input type="checkbox" value="history"> CORE + NON-CORE print history</label></div>
 <label class="field" id="adminPasswordLabel">Your current administrator password<input id="adminPassword" type="password" autocomplete="current-password" placeholder="Enter the password you created"></label><button id="adminClear" class="action ghost">Verify password & review selected deletion</button><div id="adminStatus" class="notice">Set your password first. Existing data is not changed.</div></section>`;
 let auth=null;const status=(s,warn=true)=>{A$('adminStatus').textContent=s;A$('adminStatus').className='notice '+(warn?'warn':'good')};
 function ui(){A$('adminSetupBox').classList.toggle('hidden',!!auth);A$('adminPasswordLabel').classList.toggle('hidden',!auth);A$('adminClear').disabled=!auth;}
 ui();read('auremAdminAuth').then(v=>{auth=v||null;ui();if(auth)status('Password already configured. Select categories, then enter your password.',false)}).catch(e=>status('Storage error: '+e.message));
 A$('adminCreate').onclick=async()=>{try{if(auth)throw Error('Password already configured.');if(!crypto?.subtle)throw Error('Password security unavailable. Open AUREM using the PC server / localhost.');const pass=A$('adminSetupPass').value,again=A$('adminSetupConfirm').value;if(pass.length<10)throw Error('Choose a password with at least 10 characters.');if(pass!==again)throw Error('Passwords do not match.');const salt=crypto.getRandomValues(new Uint8Array(16));const pending={salt:[...salt],hash:await derive(pass,salt)};await writeMany([['auremAdminAuth',pending]]);auth=pending;A$('adminSetupPass').value=A$('adminSetupConfirm').value='';ui();status('Your password is configured. Choose categories when you want to clear data.',false)}catch(e){status(e.message)}};
 A$('adminClear').onclick=async()=>{try{
  if(!auth)throw Error('First create your administrator password above.');
  const selected=[...A$('adminCategories').querySelectorAll('input:checked')].map(x=>x.value);if(!selected.length)throw Error('Select at least one category to clear.');
  const pass=A$('adminPassword').value;if(!pass)throw Error('Enter your administrator password.');
  if(await derive(pass,new Uint8Array(auth.salt))!==auth.hash)throw Error('Incorrect password. No data deleted.');
  if(!confirm('Delete ONLY: '+selected.join(', ')+ '? Other categories, product imports, Focus/Permanent lists and device pairing are preserved.'))return;
  if(!confirm('FINAL CONFIRMATION: Permanently clear the chosen categories?'))return;
  const entries=[];
  if(selected.includes('core')){const core=await read('session');if(core){core.selected={};core.issues={};core.overrides={};core.walkId='';core.walkStatus='in-progress';core.totalScans=0;core.duplicates=0;entries.push(['session',core]);}}
  const nc=selected.includes('noncore')||selected.includes('custom')?await read('noncore'):null;
  if(nc){if(selected.includes('noncore')){nc.selected={};nc.pending={};nc.walkStatus='in-progress';nc.sessionId='NC-'+Date.now().toString(36);}
   if(selected.includes('custom')){nc.roundRows=[];nc.roundPrices=[];nc.roundCommand='';nc.replica=null;nc.bannerText='';nc.bannerImage='';}
   entries.push(['noncore',nc]);}
  if(selected.includes('custom'))entries.push(['auremCreativeBoards',[]],['auremLoosePriceMemory',{}]);
  if(selected.includes('history'))entries.push(['printHistory',[]],['noncoreHistory',[]]);
  await writeMany(entries);
  for(const [key,val] of entries){const result=await read(key);if(JSON.stringify(result)!==JSON.stringify(val))throw Error('Could not verify cleared data in '+key+'. Recheck before continuing.');}
  A$('adminPassword').value='';A$('adminCategories').querySelectorAll('input').forEach(x=>x.checked=false);
  window.dispatchEvent(new CustomEvent('aurem-data-cleared',{detail:{selected}}));
  status('Verified! Cleared selected categories immediately. Unselected data, imports and pairing remain intact.',false);
 }catch(e){status(e.message)}};
}

/* AUREM board layout V2. Existing Core artwork and geometry preserved. */
import {money,unitPrice} from './core.js';
import {RS_SHAPE,OFF_SHAPE} from './rsoft_shapes.js';
import {NUMBER_SHAPES} from './number_shapes.js';
const esc=s=>String(s??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[ch]));
const FONT_NUMBER="'DejaVu Serif','Georgia','Times New Roman',serif";
const FONT_NAME="'Arial Narrow','Liberation Sans Narrow','DejaVu Sans Condensed','Arial',sans-serif";
const FONT_PROMO="'Georgia','DejaVu Serif','Times New Roman',serif";
const FONT_FOOT="'DejaVu Serif','Georgia','Times New Roman',serif";
// Footer-only digit treatment. Main offer numeral paths and all name fonts are unchanged.
const FONT_FOOT_DIGITS="'Arial Black','DejaVu Sans','Liberation Sans',Arial,sans-serif";
export const FORMAT_SIZE={'1/20':{cols:4,rows:5,portrait:false},'1/9':{cols:3,rows:3,portrait:false},'1/8':{cols:2,rows:4,portrait:true},'1/4':{cols:2,rows:2,portrait:false},'1/3':{cols:1,rows:3,portrait:true},'1/2':{cols:1,rows:2,portrait:true},'1/1':{cols:1,rows:1,portrait:false}};
export const sizeSpec=size=>FORMAT_SIZE[size]||FORMAT_SIZE['1/8'];
let ctx;
function measure(text,fontSize,fontFamily=FONT_NAME){try{ctx??=document.createElement('canvas').getContext('2d');ctx.font=`900 ${fontSize}px ${fontFamily}`;return ctx.measureText(String(text)).width}catch{return String(text).length*fontSize*.64}}
function txt(text,x,y,size,opts={}){
 const {family=FONT_NAME,anchor='start',weight=900,stroke=0,attrs='',targetWidth}=opts;
 const measured=Math.max(1,measure(text,size,family));
 // SVG textLength provides the measured, fixed-zone number scaling that R-Soft exhibits.
 const length=targetWidth?` textLength="${targetWidth.toFixed(2)}" lengthAdjust="spacingAndGlyphs"`:'';
 return `<text x="${x.toFixed(2)}" y="${y.toFixed(2)}" fill="#000" font-family="${family}" font-size="${size.toFixed(2)}" font-weight="${weight}" text-anchor="${anchor}"${length} ${stroke?`stroke="#000" stroke-width="${stroke}" paint-order="stroke"`:''} ${attrs}>${esc(text)}</text>`;
}
// The MRP/Price/boxed unit figures use a clean, compact bold font, while
// their labels retain the original V3 typeface and every original baseline.
// A natural-width <tspan> is used instead of changing or retracing offer numerals.
function footerDigitSegments(value){
 const str=String(value);
 return str.replace(/(\d[\d,.]*)/g,(m)=>`<tspan font-family="${FONT_FOOT_DIGITS}" font-size="1.055em" font-weight="900" stroke-width="1.05">${esc(m)}</tspan>`).replace(/^/, '');
}
function footerWidth(value,size,family){
 const str=String(value);let width=0,last=0;
 for(const m of str.matchAll(/\d[\d,.]*/g)){
  width+=measure(str.slice(last,m.index),size,family);
  width+=measure(m[0],size*1.055,FONT_FOOT_DIGITS);
  last=m.index+m[0].length;
 }
 width+=measure(str.slice(last),size,family);
 return width;
}
function footerText(value,x,y,size,opts={}){
 const {family=FONT_FOOT,anchor='start',stroke=1.7,attrs='',maxWidth,targetWidth}=opts;
 const content=footerDigitSegments(esc(value));
 // For this font-sensitive SVG label, shrink *horizontally only* if the
 // original footer slot would otherwise overflow. Never alter print geometry.
 const natural=footerWidth(value,size,family);
 const allowed=maxWidth??targetWidth;
 const drawW=allowed?Math.min(natural,allowed):natural;
 const fitted=allowed?` textLength="${drawW.toFixed(2)}" lengthAdjust="spacingAndGlyphs"`:'';
 return `<text x="${x.toFixed(2)}" y="${y.toFixed(2)}" fill="#000" font-family="${family}" font-size="${size.toFixed(2)}" font-weight="900" text-anchor="${anchor}" aria-label="${esc(value)}"${fitted} ${stroke?`stroke="#000" stroke-width="${stroke}" paint-order="stroke"`:''} ${attrs}>${content}</text>`;
}
function shape(asset,x,y,width,height,attrs=''){
 return `<g ${attrs} transform="translate(${x.toFixed(2)} ${y.toFixed(2)}) scale(${(width/asset.width).toFixed(6)} ${(height/asset.height).toFixed(6)})"><path d="${asset.d}" fill="black" fill-rule="evenodd"/></g>`;
}
const pad=s=>String(s??'').trim().replace(/\s+/g,' ');
function nameBand(n,W,H){
 n=pad(n);if(!n)return {svg:'',overflow:true,lines:[]};
 const wide=W*.952,origFont=H*.191, twoFont=H*.095;
 // Preserve V2's accepted name region, switching ONLY to classic condensed sans letterforms.
 // Break only if it would require excessive horizontal compression. Maximum two lines.
 const singleWidth=measure(n,origFont);
 const chooseSingle=singleWidth/wide<3.25;
 if(chooseSingle){
   return {svg:txt(n,W/2,H*.700,origFont,{anchor:'middle',targetWidth:wide,stroke:2.7,attrs:'data-zone="product-name"'}),overflow:false,lines:[n]};
 }
 const words=n.split(' ');let best=null;
 for(let i=1;i<words.length;i++){
  const a=words.slice(0,i).join(' '),b=words.slice(i).join(' '),wa=measure(a,twoFont),wb=measure(b,twoFont);
  const worst=Math.max(wa,wb)/wide,balance=Math.abs(wa-wb)/wide;
  const cost=worst+balance*.12;
  if(!best||cost<best.cost)best={a,b,wa,wb,worst,cost};
 }
 if(!best||best.worst>3.25)return{svg:'',overflow:true,lines:[]};
 const one=txt(best.a,W/2,H*.620,twoFont,{anchor:'middle',targetWidth:Math.min(wide,Math.max(wide*.67,best.wa)),stroke:1.1,attrs:'data-zone="product-name"'});
 const two=txt(best.b,W/2,H*.724,twoFont,{anchor:'middle',targetWidth:Math.min(wide,Math.max(wide*.67,best.wb)),stroke:1.1,attrs:'data-zone="product-name"'});
 return {svg:one+two,overflow:false,lines:[best.a,best.b]};
}
function footer(p,fmt,W,H){
 const left=fmt.hideMrp?'':`MRP ₹ ${money(fmt.mrpCents)}`;
 const right=['₹ OFF','% OFF'].includes(fmt.format)?`Price ₹ ${money(fmt.spCents)}`:'';
 // Original PPT: footer's raster band starts at 77.9% and has ~12% height.
 const base=H*.116,y=H*.842;
 if(!left&&!right)return{svg:'',overflow:false};
 if(right){
  const span=Math.max(1,footerWidth(left,base,FONT_FOOT)+footerWidth(right,base,FONT_FOOT));
  const w=W*.86;const factor=Math.min(1,w/span,(W*.430)/Math.max(1,footerWidth(left,base,FONT_FOOT)),(W*.430)/Math.max(1,footerWidth(right,base,FONT_FOOT)));
  const size=base*factor;
  return{svg:footerText(left,W*.032,y,size,{family:FONT_FOOT,stroke:1.7,attrs:'data-zone="footer"',maxWidth:W*.43})+footerText(right,W*.970,y,size,{family:FONT_FOOT,anchor:'end',stroke:1.7,attrs:'data-zone="footer"',maxWidth:W*.43}),overflow:false};
 }
 return {svg:footerText(left,W/2,y,base,{family:FONT_FOOT,anchor:'middle',stroke:1.7,attrs:'data-zone="footer"',maxWidth:W*.91}),overflow:false};
}
function ribbon(str,W,H){
 // Upper-left angled text ribbon, sized to stay clear of main glyphs.
 const rw=W*.25,rh=H*.081,fs=H*.032;
 const inner=`<rect x="0" y="0" width="${rw}" height="${rh}" fill="white" stroke="#000" stroke-width="3.5"/>${txt(str,rw/2,rh*.70,fs,{family:FONT_FOOT,anchor:'middle',targetWidth:rw*.94,stroke:.4})}`;
 return `<g data-zone="ribbon" transform="translate(${W*.029} ${H*.288}) rotate(-35)">${inner}</g>`;
}

// SVG path numerals prevent platform font substitution and fill the same measured slot for all digit counts.
function numericArt(text,x,y,w,h){
 const chars=String(text).split('');let cursor=0,minx=Infinity,miny=Infinity,maxx=-Infinity,maxy=-Infinity;
 const parts=[];
 for(const c of chars){const g=NUMBER_SHAPES[c];if(!g)return txt(text,x+w/2,y+h,H*.5,{family:FONT_NUMBER,anchor:'middle',targetWidth:w});
  const [x0,y0,x1,y1]=g.bounds;minx=Math.min(minx,cursor+x0);maxx=Math.max(maxx,cursor+x1);miny=Math.min(miny,y0);maxy=Math.max(maxy,y1);
  parts.push(`<path d="${g.d}" transform="translate(${cursor} 0)" fill="black"/>`);cursor+=g.advance;
 }
 const iw=Math.max(1,maxx-minx),ih=Math.max(1,maxy-miny);
 return `<g data-zone="offer-number" transform="translate(${x.toFixed(3)} ${(y+h).toFixed(3)}) scale(${(w/iw).toFixed(7)} ${(-h/ih).toFixed(7)}) translate(${-minx} ${-miny})">${parts.join('')}</g>`;
}

function offer(p,fmt,W,H){
 if(fmt.format==='B1G1'||fmt.format==='B1G2'){
  const isTwo=fmt.format==='B1G2',num=isTwo?'2':'1';
  const fs=H*.292;
  const width=W*.56;
  return {svg:txt('BUY 1',W*.555,H*.287,fs,{family:FONT_PROMO,anchor:'middle',targetWidth:width,stroke:3.8,attrs:'data-zone="offer"'})+
              txt('GET '+num,W*.555,H*.535,fs,{family:FONT_PROMO,anchor:'middle',targetWidth:width,stroke:3.8,attrs:'data-zone="offer"'})+
              txt('FREE',W*.980,H*.525,H*.123,{family:FONT_PROMO,anchor:'end',targetWidth:W*.14,stroke:1.5,attrs:'data-zone="offer"'}),overflow:false};
 }
 const format=fmt.format,only=format==='ONLY',pct=format==='% OFF';
 const number=pct?`${fmt.value}%`:only?money(fmt.spCents):money(fmt.diffCents);
 // Position derived from PPT: rupee x 14-26%, number x 30-75%, Off x 77-99%.
 const x=W*.308,nw=W*.438,baseline=H*.465;
 const numeric=numericArt(number,x,H*.069,nw,H*.421);
 const currency=pct?'':shape(RS_SHAPE,W*.146,H*.290,W*.115,H*.204,'data-zone="currency"');
 let qualifier='';
 if(only){qualifier=txt('ONLY',W*.985,H*.478,H*.129,{family:FONT_FOOT,anchor:'end',targetWidth:W*.225,stroke:2.2,attrs:'data-zone="qualifier"'});}
 else {qualifier=shape(OFF_SHAPE,W*.768,H*.389,W*.213,H*.149,'data-zone="qualifier"');}
 return {svg:currency+numeric+qualifier,overflow:false};
}
function focusStar(W,H,small=false){
 // Measured from the user's blue placement mark and R-Soft reference.
 // Larger, but safely inside the original border and clear of BUY/GET text.
 const r=Math.min(W*(small?.035:.032),H*(small?.070:.060));
 const x=W*.900, y=H*(small?.112:.099);let points='';
 for(let i=0;i<10;i++){const a=-Math.PI/2+i*Math.PI/5,rr=i%2?r*.45:r;points+=`${(x+rr*Math.cos(a)).toFixed(3)},${(y+rr*Math.sin(a)).toFixed(3)} `;}
 return `<polygon data-zone="focus" points="${points}" fill="#000" stroke="#fff" stroke-width="3"/>`;
}
function compactName(str,W,H){
 const n=pad(str), max=W*.94,base=H*.194;
 if(!n)return{svg:'',overflow:true,lines:[]};
 // The real R-Soft 1/20 uses one extremely condensed, bold line where feasible.
 const mw=Math.max(1,measure(n,base,FONT_PROMO));
 if(mw/max<4.8) return {svg:txt(n,W/2,H*.730,base,{family:FONT_PROMO,anchor:'middle',targetWidth:max,stroke:2.0,attrs:'data-zone="product-name"'}),overflow:false,lines:[n]};
 const words=n.split(/\s+/);let candidate=null;
 for(let i=1;i<words.length;i++){
  const a=words.slice(0,i).join(' '),b=words.slice(i).join(' '),v=Math.max(measure(a,base*.55,FONT_PROMO),measure(b,base*.55,FONT_PROMO));
  if(!candidate||v<candidate.v)candidate={a,b,v};
 }
 if(!candidate||candidate.v/max>4.8)return{svg:'',overflow:true,lines:[]};
 return{svg:txt(candidate.a,W/2,H*.658,base*.59,{family:FONT_PROMO,anchor:'middle',targetWidth:max,stroke:1.4})+txt(candidate.b,W/2,H*.753,base*.59,{family:FONT_PROMO,anchor:'middle',targetWidth:max,stroke:1.4}),overflow:false,lines:[candidate.a,candidate.b]};
}
// Mahir's Style is an OPT-IN 1/20 buy/get footer experiment.
// It is deliberately disconnected from the original 1/20 Standard renderer.
// In particular it cannot alter the main BUY/GET artwork, product name, star,
// board dimensions, spacing rules for other sizes, or any R-Soft-style number.
function mahir20Footer(product,fmt,choice,W,H){
 const mrp=`MRP ₹ ${money(fmt.mrpCents)}/-`;
 const per=unitPrice(product,fmt,choice);
 if(!per||per.unit!=='PCS')return null;
 const unit=`₹${money(per.amount)} PER PCS`;
 const box={x:W*.534,y:H*.810,w:W*.433,h:H*.151};
 const mrpSize=H*.139; // retain the original 1/20 MRP font height
 const leftSpace=box.x-W*.039-W*.018;
 const leftWidth=Math.max(1,footerWidth(mrp,mrpSize,FONT_PROMO));
 // Scaling, if needed, is only horizontal inside this optional mode.
 // Existing baseline styles and font sizes are never changed.
 const leftFit=Math.min(leftWidth,leftSpace);
 const mrpArt=footerText(mrp,W*.039,H*.912,mrpSize,{family:FONT_PROMO,maxWidth:leftFit,stroke:1.9,attrs:'data-zone="mahir-mrp"'});
 const unitSize=H*.120;
 const unitSpace=box.w*.932;
 const unitWidth=Math.max(1,footerWidth(unit,unitSize,FONT_PROMO));
 const textWidth=Math.min(unitWidth,unitSpace);
 const boxArt=`<rect data-zone="mahir-per-pcs-box" x="${box.x.toFixed(2)}" y="${box.y.toFixed(2)}" width="${box.w.toFixed(2)}" height="${box.h.toFixed(2)}" fill="none" stroke="#000" stroke-width="4"/>`;
 const labelArt=footerText(unit,box.x+box.w/2,box.y+box.h*.780,unitSize,{family:FONT_PROMO,anchor:'middle',maxWidth:textWidth,stroke:2.1,attrs:'data-zone="mahir-per-pcs"'});
 return mrpArt+boxArt+labelArt;
}

function compactBoardSvg(product,fmt,choice,{watermark=false}={}){
 const W=1400,H=780;
 const b1=['B1G1','B1G2'].includes(fmt.format);
 const nm=compactName(choice.name||product.name,W,H);
 let main='';
 if(b1){
  const num=fmt.format==='B1G2'?'2':'1';
  main=txt('BUY 1',W*.41,H*.250,H*.305,{family:FONT_PROMO,anchor:'middle',targetWidth:W*.68,stroke:3.5})+
       txt('GET '+num,W*.41,H*.520,H*.305,{family:FONT_PROMO,anchor:'middle',targetWidth:W*.68,stroke:3.5})+
       txt('FREE',W*.952,H*.520,H*.135,{family:FONT_PROMO,anchor:'end',targetWidth:W*.17,stroke:1.8});
 }else{
  const pct=fmt.format==='% OFF',only=fmt.format==='ONLY';
  const val=pct?String(fmt.value)+'%':money(only?fmt.spCents:fmt.diffCents);
  // Digit-count independent: the actual numeric artwork stretches to a single designated region.
  const zoneX=W*.205, zoneW=W*.585, zoneH=H*.452;
  // A single digit must look commanding but not distorted into a pancake.
  // Fill the vertical allocation, preserve a strong recognisable numeral silhouette.
  const drawW=val.replace(/[^0-9]/g,'').length===1?Math.min(zoneW,zoneH*1.20):zoneW;
  const numeric=numericArt(val,zoneX+(zoneW-drawW)/2,H*.028,drawW,zoneH);
  const rupee=pct?'':shape(RS_SHAPE,W*.025,H*.267,W*.16,H*.226);
  const qualifier=txt(only?'ONLY':'off',W*.981,H*.500,H*.149,{family:FONT_PROMO,anchor:'end',targetWidth:W*.175,stroke:1.4});
  main=rupee+numeric+qualifier;
 }
 const footText=b1?`MRP ₹ ${money(fmt.mrpCents)}/-`:'';
 const mahir=b1&&choice.style20==='mahir';
 const foot=mahir?mahir20Footer(product,fmt,choice,W,H):b1?footerText(footText,W/2,H*.899,H*.139,{family:FONT_PROMO,anchor:'middle',maxWidth:W*.70,stroke:1.9,attrs:'data-zone="compact-footer"'}):
     footerText(fmt.hideMrp?'':`MRP ₹ ${money(fmt.mrpCents)}`,W*.035,H*.904,H*.124,{family:FONT_PROMO,maxWidth:W*.445,stroke:1.6,attrs:'data-zone="compact-footer"'})+
     (['₹ OFF','% OFF'].includes(fmt.format)?footerText(`Price ₹ ${money(fmt.spCents)}`,W*.971,H*.904,H*.124,{family:FONT_PROMO,anchor:'end',maxWidth:W*.445,stroke:1.6,attrs:'data-zone="compact-footer"'}):'');
 const watermarkSvg='';
 // The 1/20 specific exception: NO per-unit ribbon, not even for B1G1/B1G2.
 const art=`<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}"><rect width="${W}" height="${H}" fill="white"/><rect x="7" y="7" width="${W-14}" height="${H-14}" fill="none" stroke="black" stroke-width="10"/>${main}${nm.svg}${foot}${fmt.focus?focusStar(W,H,true):''}${watermarkSvg}</svg>`;
 return{svg:art,width:W,height:H,overflow:nm.overflow,lines:nm.lines,unit:mahir?unitPrice(product,fmt,choice):null};
}

export function boardSvg(product,fmt,choice={size:'1/8'},{watermark=false}={}){
 const W=choice.size==='1/3'?1400:1000,H=choice.size==='1/3'?660:705;
 if(fmt.error)return{svg:'',width:W,height:H,overflow:true};
 if(choice.size==='1/20')return compactBoardSvg(product,fmt,choice,{watermark});
 const name=nameBand(choice.name||product.name,W,H),foot=footer(product,fmt,W,H),main=offer(product,fmt,W,H);
 const unit=unitPrice(product,fmt,choice);
 const unitSvg=unit?ribbon(`₹ ${money(unit.amount)} Per ${unit.unit.toLowerCase()}`,W,H):'';
 const warn='';
 const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}"><rect width="${W}" height="${H}" fill="white"/><rect x="9" y="9" width="${W-18}" height="${H-18}" fill="none" stroke="#000" stroke-width="14"/>${main.svg}${unitSvg}${name.svg}${foot.svg}${fmt.focus?focusStar(W,H):''}${warn}</svg>`;
 return {svg,width:W,height:H,overflow:main.overflow||name.overflow||foot.overflow,lines:name.lines,unit};
}
export function pagePlan(selections){
 const groups=new Map();for(const item of selections){const size=item.choice.size||'1/8';if(!FORMAT_SIZE[size])throw Error('Unknown board size');const n=Number(item.choice.copies);if(!Number.isInteger(n)||n<1||n>300)throw Error('Copies must be a whole number 1 to 300');if(!groups.has(size))groups.set(size,[]);for(let i=0;i<n;i++)groups.get(size).push(item)}
 const pages=[];for(const[size,items]of groups){const g=sizeSpec(size);for(let j=0;j<items.length;j+=g.cols*g.rows)pages.push({...g,size,items:items.slice(j,j+g.cols*g.rows)})}return pages;
}
export function a4Svg(page,{watermark=false}={}){
 const W=page.portrait?210:297,H=page.portrait?297:210,cw=W/page.cols,ch=H/page.rows;let art=`<rect width="${W}" height="${H}" fill="white"/>`;
 page.items.forEach((item,i)=>{const b=boardSvg(item.product,item.format,item.choice,{watermark});const x=page.mode==='saver'?item.x:(i%page.cols)*cw,y=page.mode==='saver'?item.y:Math.floor(i/page.cols)*ch;const sw=page.mode==='saver'?item.w:cw,sh=page.mode==='saver'?item.h:ch;
 art+=b.svg.replace(/^<svg[^>]+>/,`<svg x="${x}" y="${y}" width="${sw}" height="${sh}" viewBox="0 0 ${b.width} ${b.height}" preserveAspectRatio="none">`);
 });return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}mm" height="${H}mm" viewBox="0 0 ${W} ${H}" aria-label="A4 printable layout">${art}</svg>`;
}
// Page Saver operates on complete physical board rectangles; it never scales or rotates artwork.
// It is deliberately separate from Standard Mode, which remains the V2 arrangement.
export function boardPhysicalSize(size){
 const g=sizeSpec(size),W=g.portrait?210:297,H=g.portrait?297:210;
 return{w:W/g.cols,h:H/g.rows};
}
export function paperGroup(item){return item.format.focus?'YELLOW':'WHITE';}
export function planByPaper(items,mode='standard',margin=0){
 const out=[];
 for(const color of ['WHITE','YELLOW']){
  const group=items.filter(x=>paperGroup(x)===color);if(!group.length)continue;
  const pages=mode==='saver'?pageSaverPlan(group,margin):pagePlan(group);
  for(const p of pages)out.push({...p,paper:color,mode});
 }
 return out;
}
export function pageSaverPlan(items,margin=0){
 if(![0,1,2,3].includes(Number(margin)))throw Error('Unsupported printer margin');
 const copies=[];
 for(const item of items){const g=boardPhysicalSize(item.choice.size),n=Number(item.choice.copies);
  if(!Number.isInteger(n)||n<1||n>300)throw Error('Invalid number of copies');
  for(let i=0;i<n;i++)copies.push({...item,phys:g});
 }
 // Sorting never changes requested copies or any board's dimensions.
 copies.sort((a,b)=>b.phys.w*b.phys.h-a.phys.w*a.phys.h);
 const pages=[];
 const nearly=(a,b)=>Math.abs(a-b)<.00001;
 const pack=(candidate,item)=>{
  // Best short-side-fit over free non-overlapping rectangles; never rotate.
  let best=-1,score=Infinity;
  for(let i=0;i<candidate.free.length;i++){
   const r=candidate.free[i];if(item.phys.w>r.w+1e-8||item.phys.h>r.h+1e-8)continue;
   const t=Math.min(r.w-item.phys.w,r.h-item.phys.h);
   if(t<score){score=t;best=i;}
  }
  if(best<0)return false;
  const r=candidate.free.splice(best,1)[0],x=r.x,y=r.y,w=item.phys.w,h=item.phys.h;
  candidate.items.push({...item,x,y,w,h});
  const rw=r.w-w,rh=r.h-h;
  // Guillotine split with non-overlapping free regions (no duplicated area).
  if(rw>1e-8&&rh>1e-8){
   if(rw*rh < rw*h){candidate.free.push({x:x+w,y,w:rw,h:r.h});candidate.free.push({x,y:y+h,w,h:rh});}
   else {candidate.free.push({x:x+w,y,w:rw,h});candidate.free.push({x,y:y+h,w:r.w,h:rh});}
  }else{
   if(rw>1e-8)candidate.free.push({x:x+w,y,w:rw,h:r.h});
   if(rh>1e-8)candidate.free.push({x,y:y+h,w:r.w,h:rh});
  }
  return true;
 };
 for(const item of copies){let done=false;
  for(const pg of pages)if(pack(pg,item)){done=true;break;}
  if(!done){const newPage={portrait:false,mode:'saver',size:'mixed',cols:0,rows:0,items:[],free:[{x:margin,y:margin,w:297-2*margin,h:210-2*margin}]};
   if(!pack(newPage,item))throw Error(`A ${item.choice.size} board cannot fit at its physical size with ${margin}mm margins. Select zero margin/borderless, or use Standard Mode.`);
   pages.push(newPage);
  }
 }
 return pages;
}
const bytes=s=>new TextEncoder().encode(s);
const join=arrays=>{let n=0;for(const a of arrays)n+=a.length;const out=new Uint8Array(n);let off=0;for(const a of arrays){out.set(a,off);off+=a.length}return out};
export function jpegPdf(pages){
 const obj=[null],alloc=()=>{obj.push(null);return obj.length-1},root=alloc(),tree=alloc(),kidIds=[];
 for(const page of pages){const id=alloc(),im=alloc(),stream=alloc();kidIds.push(id);const B=page.jpeg,W=page.wPt,H=page.hPt;
  obj[id]=bytes(`<< /Type /Page /Parent ${tree} 0 R /MediaBox [0 0 ${W.toFixed(3)} ${H.toFixed(3)}] /Resources << /XObject << /Im${im} ${im} 0 R >> >> /Contents ${stream} 0 R >>`);
  obj[im]=[bytes(`<< /Type /XObject /Subtype /Image /Width ${page.wPx} /Height ${page.hPx} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${B.length} >>\nstream\n`),B,bytes('\nendstream')];
  const drawing=`q ${W.toFixed(3)} 0 0 ${H.toFixed(3)} 0 0 cm /Im${im} Do Q`;
  obj[stream]=bytes(`<< /Length ${drawing.length} >>\nstream\n${drawing}\nendstream`);
 }
 obj[root]=bytes(`<< /Type /Catalog /Pages ${tree} 0 R >>`);obj[tree]=bytes(`<< /Type /Pages /Kids [${kidIds.map(x=>x+' 0 R').join(' ')}] /Count ${kidIds.length} >>`);
 let file=[bytes('%PDF-1.4\n% AUREM\n')],offset=file[0].length;const offsets=[0];for(let i=1;i<obj.length;i++){offsets[i]=offset;const parts=[bytes(`${i} 0 obj\n`),...(Array.isArray(obj[i])?obj[i]:[obj[i]]),bytes('\nendobj\n')];for(const part of parts){file.push(part);offset+=part.length}}
 const start=offset;let xref=`xref\n0 ${obj.length}\n0000000000 65535 f \n`;for(let i=1;i<obj.length;i++)xref+=String(offsets[i]).padStart(10,'0')+' 00000 n \n';file.push(bytes(xref+`trailer\n<< /Size ${obj.length} /Root ${root} 0 R >>\nstartxref\n${start}\n%%EOF`));return new Blob(file,{type:'application/pdf'});
}
export function svgImage(svg){return new Promise((res,rej)=>{const blob=new Blob([svg],{type:'image/svg+xml;charset=utf-8'}),u=URL.createObjectURL(blob),img=new Image();img.onload=()=>{URL.revokeObjectURL(u);res(img)};img.onerror=()=>{URL.revokeObjectURL(u);rej(Error('Unable to render sheet preview image'))};img.src=u})}
export async function makeTestPDF(selections,onProgress=()=>{},preparedPages=null){
 const started=performance.now(),planStarted=performance.now();if(!selections.length)throw Error('Scan products first.');const plan=preparedPages||pagePlan(selections),planningMs=performance.now()-planStarted;
 if(plan.length>150)throw Error('More than 150 A4 review pages. Split into smaller batches.');
 const pages=[];let done=0,svgMs=0,canvasMs=0,jpegMs=0;
 for(const page of plan){const pwmm=page.portrait?210:297,phmm=page.portrait?297:210,pxPerMm=6;
  const canv=document.createElement('canvas');canv.width=Math.round(pwmm*pxPerMm);canv.height=Math.round(phmm*pxPerMm);const wPx=canv.width,hPx=canv.height;
  let im=null;try{const c=canv.getContext('2d',{alpha:false});c.fillStyle='white';c.fillRect(0,0,wPx,hPx);let mark=performance.now();const art=a4Svg(page,{watermark:false});im=await svgImage(art);svgMs+=performance.now()-mark;mark=performance.now();c.drawImage(im,0,0,wPx,hPx);canvasMs+=performance.now()-mark;
   mark=performance.now();const jpeg=await new Promise((resolve,reject)=>canv.toBlob(b=>b?b.arrayBuffer().then(a=>resolve(new Uint8Array(a))):reject(Error('Could not encode TEST PDF page')),'image/jpeg',.95));jpegMs+=performance.now()-mark;pages.push({jpeg,wPt:pwmm*72/25.4,hPt:phmm*72/25.4,wPx,hPx});onProgress(++done,plan.length,{stage:'render',planningMs,svgMs,canvasMs,jpegMs,serializationMs:0,totalMs:performance.now()-started});
  }finally{if(im)im.src='';canv.width=0;canv.height=0}await new Promise(resolve=>setTimeout(resolve,0));
 }
 const serializationStarted=performance.now(),blob=jpegPdf(pages),serializationMs=performance.now()-serializationStarted;onProgress(done,plan.length,{stage:'complete',planningMs,svgMs,canvasMs,jpegMs,serializationMs,totalMs:performance.now()-started,bytes:blob.size});return blob;
}

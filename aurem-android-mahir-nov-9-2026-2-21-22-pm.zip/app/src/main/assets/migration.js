/* One-time verified migration between previous browser build and the desktop WebView profile. */
const M$=id=>document.getElementById(id);
const BACKUP_KEYS=['session','master','printHistory','noncore','noncoreHistory','auremLoosePriceMemory','auremLooseConfirmedMappings','auremCreativeBoards','auremVerifiedProductsV7','auremAuditLocationsV7'];

function store(){
  return new Promise((ok,no)=>{
    const r=indexedDB.open('AUREM_Offline_Data',1);
    r.onsuccess=()=>ok(r.result);
    r.onerror=()=>no(r.error);
  });
}

function countRecords(records){
  const counts={};
  if(records.auremVerifiedProductsV7&&typeof records.auremVerifiedProductsV7==='object'){
    counts.verifiedProducts=Object.keys(records.auremVerifiedProductsV7).length;
  }
  if(records.auremAuditLocationsV7&&typeof records.auremAuditLocationsV7==='object'){
    counts.racks=(records.auremAuditLocationsV7.racks||[]).length;
    counts.categories=(records.auremAuditLocationsV7.categories||[]).length;
  }
  if(Array.isArray(records.printHistory)) counts.printHistory=records.printHistory.length;
  if(Array.isArray(records.noncoreHistory)) counts.noncoreHistory=records.noncoreHistory.length;
  if(records.auremLooseConfirmedMappings&&typeof records.auremLooseConfirmedMappings==='object'){
    counts.looseMappings=Object.keys(records.auremLooseConfirmedMappings).length;
  }
  if(records.auremLoosePriceMemory&&typeof records.auremLoosePriceMemory==='object'){
    counts.loosePrices=Object.keys(records.auremLoosePriceMemory).length;
  }
  if(Array.isArray(records.auremCreativeBoards)) counts.creativeBoards=records.auremCreativeBoards.length;
  return counts;
}

export function mountMigration(){
  const mount=M$('migrationMount');if(!mount)return;
  mount.innerHTML=`<section class="card"><h2>Data safety &amp; desktop migration</h2><p class="quiet">Export a verified private backup before moving between browser AUREM and the desktop version or reinstalling. Safeguards saved boards, imports, audit rack locations, corrected names, print history and Loose Grocery mappings with integrity checks.</p><div class="action-grid"><button id="auremBackupAll" class="action ghost">Download Verified AUREM Backup</button><label class="upload">Restore verified AUREM backup<input id="auremRestoreAll" type="file" accept=".json,application/json"></label></div><div id="auremBackupNote" class="notice">Keep backup files securely. They contain store product records.</div></section>`;
  
  const note=(message,err=false)=>{
    M$('auremBackupNote').textContent=message;
    M$('auremBackupNote').className='notice '+(err?'error':'good');
  };

  M$('auremBackupAll').addEventListener('click',async()=>{
    try{
      const db=await store();
      let records={};
      try{
        records=await new Promise((ok,no)=>{
          const tx=db.transaction('data');
          const obj=tx.objectStore('data'),data={};
          for(const k of BACKUP_KEYS){
            const r=obj.get(k);
            r.onsuccess=()=>{if(r.result!==undefined)data[k]=r.result;};
          }
          tx.oncomplete=()=>ok(data);
          tx.onerror=()=>no(tx.error);
        });
      }finally{
        db.close();
      }
      const counts=countRecords(records);
      const payload={
        format:'AUREM-FULL-BACKUP-V7',
        version:'7.0',
        date:new Date().toISOString(),
        counts,
        records
      };
      const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});
      const fileName='AUREM_VERIFIED_BACKUP_'+new Date().toISOString().slice(0,10)+'.json';
      if(window.AUREMNative?.saveFile){
        const reader=new FileReader();
        reader.onloadend=()=>window.AUREMNative.saveFile(reader.result.split(',')[1],fileName,'application/json');
        reader.readAsDataURL(blob);
      }else{
        const url=URL.createObjectURL(blob);
        const a=document.createElement('a');
        a.href=url;
        a.download=fileName;
        a.click();
        setTimeout(()=>URL.revokeObjectURL(url),10000);
      }
      const summaryParts=[];
      if(counts.verifiedProducts) summaryParts.push(`${counts.verifiedProducts} verified products`);
      if(counts.racks) summaryParts.push(`${counts.racks} racks`);
      if(counts.printHistory) summaryParts.push(`${counts.printHistory} print jobs`);
      if(counts.looseMappings) summaryParts.push(`${counts.looseMappings} loose grocery mappings`);
      note(`Verified backup downloaded (${summaryParts.length?summaryParts.join(', '):'clean snapshot'}). Safeguard this file.`);
    }catch(e){
      note('Backup failed: '+e.message,true);
    }
  });

  M$('auremRestoreAll').addEventListener('change',async ev=>{
    try{
      const f=ev.target.files[0];if(!f)return;
      if(f.size>80_000_000)throw Error('Backup file exceeds 80MB limit');
      const doc=JSON.parse(await f.text());
      if(doc.format!=='AUREM-FULL-BACKUP-V7'||!doc.records||typeof doc.records!=='object'||Array.isArray(doc.records)){
        throw Error('Not a valid AUREM-FULL-BACKUP-V7 format file');
      }
      const keys=Object.keys(doc.records);
      if(keys.some(k=>!BACKUP_KEYS.includes(k))){
        throw Error('Backup contains unrecognized data categories');
      }
      const counts=countRecords(doc.records);
      const summaryMsg=[
        'Verify & Restore AUREM Full Backup:',
        counts.verifiedProducts ? `• Verified Products: ${counts.verifiedProducts}` : null,
        counts.racks ? `• Racks / Categories: ${counts.racks} racks, ${counts.categories||0} categories` : null,
        counts.printHistory ? `• Print History: ${counts.printHistory} jobs` : null,
        counts.looseMappings ? `• Loose Grocery Mappings: ${counts.looseMappings}` : null,
        counts.creativeBoards ? `• AI Creative Boards: ${counts.creativeBoards}` : null,
        '',
        'Existing categories in this app will be updated and merged. Continue?'
      ].filter(x=>x!==null).join('\n');

      if(!confirm(summaryMsg)) return;

      const db=await store();
      try{
        await new Promise((ok,no)=>{
          const tx=db.transaction('data','readwrite');
          for(const k of keys){
            tx.objectStore('data').put(doc.records[k],k);
          }
          tx.oncomplete=ok;
          tx.onerror=()=>no(tx.error);
        });
      }finally{
        db.close();
      }
      note('Restored verified data successfully. AUREM will now reload to apply all records.');
      setTimeout(()=>location.reload(),800);
    }catch(e){
      note('Restore failed: '+e.message,true);
    }finally{
      ev.target.value='';
    }
  });
}

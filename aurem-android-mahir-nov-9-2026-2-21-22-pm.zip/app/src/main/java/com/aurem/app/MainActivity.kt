package com.aurem.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.webkit.JsResult
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import androidx.lifecycle.lifecycleScope
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import kotlinx.coroutines.launch
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var credentialManager: CredentialManager
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private var pendingPermissionRequest: PermissionRequest? = null

    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val uris = if (result.resultCode == Activity.RESULT_OK) {
            val data = result.data
            if (data?.clipData != null) {
                val count = data.clipData!!.itemCount
                Array(count) { i -> data.clipData!!.getItemAt(i).uri }
            } else if (data?.data != null) {
                arrayOf(data.data!!)
            } else null
        } else null
        val callback = fileChooserCallback
        fileChooserCallback = null
        callback?.onReceiveValue(uris)
    }

    private val cameraPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            pendingPermissionRequest?.grant(pendingPermissionRequest?.resources)
        } else {
            pendingPermissionRequest?.deny()
        }
        pendingPermissionRequest = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    fun runOcrCallback(script: String) { runOnUiThread { webView.evaluateJavascript(script, null) } }

    fun getSignedInUserJson(): String {
        val prefs = getSharedPreferences("aurem_auth", Context.MODE_PRIVATE)
        val signedIn = prefs.getBoolean("signed_in", false)
        val json = JSONObject()
        json.put("signedIn", signedIn)
        if (signedIn) {
            json.put("email", prefs.getString("email", "") ?: "")
            json.put("displayName", prefs.getString("display_name", "") ?: "")
            json.put("photoUrl", prefs.getString("photo_url", "") ?: "")
            json.put("idToken", prefs.getString("id_token", "") ?: "")
        }
        return json.toString()
    }

    fun getGoogleIdToken(): String {
        val prefs = getSharedPreferences("aurem_auth", Context.MODE_PRIVATE)
        return prefs.getString("id_token", "") ?: ""
    }

    private fun saveAuthState(signedIn: Boolean, email: String, displayName: String, photoUrl: String, idToken: String = "") {
        val prefs = getSharedPreferences("aurem_auth", Context.MODE_PRIVATE)
        prefs.edit()
            .putBoolean("signed_in", signedIn)
            .putString("email", email)
            .putString("display_name", displayName)
            .putString("photo_url", photoUrl)
            .putString("id_token", idToken)
            .apply()
    }

    fun notifyAuthChanged(signedIn: Boolean, email: String, displayName: String, photoUrl: String, idToken: String = "") {
        val json = JSONObject().apply {
            put("signedIn", signedIn)
            put("email", email)
            put("displayName", displayName)
            put("photoUrl", photoUrl)
            put("idToken", idToken)
        }
        runOnUiThread {
            webView.evaluateJavascript("window.onAuremAuthChanged && window.onAuremAuthChanged(${json})", null)
        }
    }

    companion object {
        const val PERMANENT_WEB_CLIENT_ID = "119004603451-bnmu5tolkta41d5fgas0geueekpmf8bj.apps.googleusercontent.com"
    }

    fun launchGoogleSignIn() {
        lifecycleScope.launch {
            try {
                val prefs = getSharedPreferences("aurem_auth", Context.MODE_PRIVATE)
                var rawClientId = prefs.getString("oauth_client_id", "")?.trim() ?: ""
                if (rawClientId.isEmpty()) {
                    rawClientId = getString(R.string.default_web_client_id).trim()
                }
                if (rawClientId.isEmpty()) {
                    rawClientId = PERMANENT_WEB_CLIENT_ID
                }

                Log.i("AUREM_AUTH", "Starting Google Sign-In with serverClientId=$rawClientId (Package: $packageName, SHA1: ${getCertificateSha1()})")

                val googleIdOption = GetGoogleIdOption.Builder()
                    .setFilterByAuthorizedAccounts(false)
                    .setServerClientId(rawClientId)
                    .setAutoSelectEnabled(false)
                    .build()

                val request = GetCredentialRequest.Builder()
                    .addCredentialOption(googleIdOption)
                    .build()

                val result = credentialManager.getCredential(this@MainActivity, request)
                val credential = result.credential
                var email = ""
                var displayName = ""
                var photoUrl = ""
                var idToken = ""

                Log.i("AUREM_AUTH", "Credential received: class=${credential.javaClass.simpleName}")

                if (credential is CustomCredential) {
                    val rawData = credential.data
                    Log.d("AUREM_AUTH", "CustomCredential type=${credential.type}, dataKeys=${rawData.keySet().joinToString()}")

                    if (credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                        try {
                            val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(rawData)
                            email = googleIdTokenCredential.id
                            displayName = googleIdTokenCredential.displayName ?: ""
                            photoUrl = googleIdTokenCredential.profilePictureUri?.toString() ?: ""
                            idToken = googleIdTokenCredential.idToken
                        } catch (e: Exception) {
                            Log.w("AUREM_AUTH", "GoogleIdTokenCredential.createFrom error, checking bundle keys", e)
                        }
                    }

                    // Fallback to direct bundle keys
                    if (idToken.isEmpty()) {
                        idToken = rawData.getString("com.google.android.libraries.identity.googleid.BUNDLE_KEY_ID_TOKEN")
                            ?: rawData.getString("id_token")
                            ?: rawData.getString("idToken")
                            ?: ""
                    }
                    if (email.isEmpty()) {
                        email = rawData.getString("com.google.android.libraries.identity.googleid.BUNDLE_KEY_ID")
                            ?: rawData.getString("id")
                            ?: rawData.getString("email")
                            ?: ""
                    }
                    if (displayName.isEmpty()) {
                        displayName = rawData.getString("com.google.android.libraries.identity.googleid.BUNDLE_KEY_DISPLAY_NAME")
                            ?: rawData.getString("display_name")
                            ?: rawData.getString("displayName")
                            ?: rawData.getString("name")
                            ?: ""
                    }
                    if (photoUrl.isEmpty()) {
                        photoUrl = rawData.getString("com.google.android.libraries.identity.googleid.BUNDLE_KEY_PROFILE_PICTURE_URI")
                            ?: rawData.getString("profile_picture_uri")
                            ?: rawData.getString("photoUrl")
                            ?: rawData.getString("picture")
                            ?: ""
                    }
                }

                // If idToken is present, extract claims from JWT
                if (idToken.isNotEmpty()) {
                    val parsed = parseJwtPayload(idToken)
                    if (email.isEmpty() || !email.contains("@")) {
                        val tokenEmail = parsed.optString("email", "")
                        if (tokenEmail.isNotEmpty()) email = tokenEmail
                    }
                    if (displayName.isEmpty()) {
                        displayName = parsed.optString("name", "")
                    }
                    if (photoUrl.isEmpty()) {
                        photoUrl = parsed.optString("picture", "")
                    }
                }

                if (email.isNotEmpty() || displayName.isNotEmpty()) {
                    if (email.isEmpty() && displayName.isNotEmpty()) email = displayName
                    if (displayName.isEmpty() && email.isNotEmpty()) displayName = email.substringBefore("@")
                    saveAuthState(true, email, displayName, photoUrl, idToken)
                    notifyAuthChanged(true, email, displayName, photoUrl, idToken)
                    Toast.makeText(this@MainActivity, "Signed in as $displayName", Toast.LENGTH_SHORT).show()
                } else {
                    val credType = (credential as? CustomCredential)?.type ?: credential.javaClass.simpleName
                    val msg = "Received credential ($credType) but could not extract user profile."
                    Log.e("AUREM_AUTH", msg)
                    runOnUiThread {
                        webView.evaluateJavascript("window.onAuremAuthError && window.onAuremAuthError(${JSONObject.quote(msg)})", null)
                    }
                }
            } catch (e: GetCredentialCancellationException) {
                Log.d("AUREM_AUTH", "Sign in cancelled by user")
                runOnUiThread {
                    webView.evaluateJavascript("window.onAuremAuthCancelled && window.onAuremAuthCancelled()", null)
                }
            } catch (e: NoCredentialException) {
                val msg = "No Google account found on device or Google Play Services needs update."
                Log.w("AUREM_AUTH", msg, e)
                Toast.makeText(this@MainActivity, msg, Toast.LENGTH_LONG).show()
                runOnUiThread {
                    webView.evaluateJavascript("window.onAuremAuthError && window.onAuremAuthError(${JSONObject.quote(msg)})", null)
                }
            } catch (e: Exception) {
                val rawMsg = e.localizedMessage ?: "Sign-in could not be completed"
                val isDevError = rawMsg.contains("10:") || rawMsg.contains("DEVELOPER_ERROR", ignoreCase = true)
                val msg = if (isDevError) {
                    "Google Sign-In configuration: in Google Cloud Console, ensure Android OAuth Client is registered for Package '$packageName' and SHA-1 '${getCertificateSha1()}'."
                } else {
                    rawMsg
                }
                Log.e("AUREM_AUTH", "Sign in error: $rawMsg", e)
                Toast.makeText(this@MainActivity, "Google Sign-In: $msg", Toast.LENGTH_LONG).show()
                runOnUiThread {
                    webView.evaluateJavascript("window.onAuremAuthError && window.onAuremAuthError(${JSONObject.quote(msg)})", null)
                }
            }
        }
    }

    private fun getCertificateSha1(): String {
        return try {
            val packageInfo = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
                packageManager.getPackageInfo(packageName, PackageManager.GET_SIGNING_CERTIFICATES)
            } else {
                @Suppress("DEPRECATION")
                packageManager.getPackageInfo(packageName, PackageManager.GET_SIGNATURES)
            }
            val signatures = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
                packageInfo.signingInfo?.apkContentsSigners
            } else {
                @Suppress("DEPRECATION")
                packageInfo.signatures
            }
            val cert = signatures?.firstOrNull()?.toByteArray() ?: return "unavailable"
            val md = java.security.MessageDigest.getInstance("SHA-1")
            val digest = md.digest(cert)
            digest.joinToString(":") { String.format("%02X", it) }
        } catch (_: Exception) {
            "8C:EF:DA:89:81:E2:33:6A:E0:B8:40:9A:A5:01:AD:6D:40:FC:B6:53"
        }
    }

    private fun parseJwtPayload(jwt: String): JSONObject {
        return try {
            val parts = jwt.split(".")
            if (parts.size >= 2) {
                val payloadB64 = parts[1]
                val decodedBytes = android.util.Base64.decode(payloadB64, android.util.Base64.URL_SAFE or android.util.Base64.NO_WRAP or android.util.Base64.NO_PADDING)
                JSONObject(String(decodedBytes, Charsets.UTF_8))
            } else {
                JSONObject()
            }
        } catch (e: Exception) {
            Log.w("AUREM_AUTH", "Failed to parse JWT payload", e)
            JSONObject()
        }
    }

    fun performSignOut() {
        lifecycleScope.launch {
            try {
                val credentialManager = CredentialManager.create(this@MainActivity)
                credentialManager.clearCredentialState(ClearCredentialStateRequest())
            } catch (e: Exception) {
                Log.w("AUREM_AUTH", "Error clearing credential state", e)
            }
            saveAuthState(false, "", "", "")
            notifyAuthChanged(false, "", "", "")
            Toast.makeText(this@MainActivity, "Signed out of Google account", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        credentialManager = CredentialManager.create(this)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content)) { view, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        val assetLoader = WebViewAssetLoader.Builder()
            .setDomain("appassets.androidplatform.net")
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView.webViewClient = object : WebViewClientCompat() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                return assetLoader.shouldInterceptRequest(request.url)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                // Initialize auth state in JavaScript once the page is ready
                val authJson = getSignedInUserJson()
                view?.evaluateJavascript("window.onAuremAuthChanged && window.onAuremAuthChanged($authJson)", null)
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onJsAlert(
                view: WebView?,
                url: String?,
                message: String?,
                result: JsResult?
            ): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("AUREM")
                    .setMessage(message)
                    .setPositiveButton(android.R.string.ok) { _, _ -> result?.confirm() }
                    .setOnCancelListener { result?.cancel() }
                    .show()
                return true
            }

            override fun onJsConfirm(
                view: WebView?,
                url: String?,
                message: String?,
                result: JsResult?
            ): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("AUREM")
                    .setMessage(message)
                    .setPositiveButton(android.R.string.ok) { _, _ -> result?.confirm() }
                    .setNegativeButton(android.R.string.cancel) { _, _ -> result?.cancel() }
                    .setOnCancelListener { result?.cancel() }
                    .show()
                return true
            }

            override fun onPermissionRequest(request: PermissionRequest) {
                val requested = request.resources
                if (requested.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) {
                    if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA)
                        == PackageManager.PERMISSION_GRANTED
                    ) {
                        request.grant(request.resources)
                    } else {
                        pendingPermissionRequest = request
                        cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                    }
                } else {
                    request.grant(request.resources)
                }
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                if (filePathCallback == null) return false
                fileChooserCallback?.onReceiveValue(null)
                fileChooserCallback = filePathCallback

                val acceptTypes = fileChooserParams?.acceptTypes.orEmpty().map { it.trim() }.filter { it.isNotEmpty() }
                val acceptsAnyFile = acceptTypes.isEmpty() || acceptTypes.any { it == "*/*" }
                val intent = if (acceptsAnyFile) {
                    Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        if (fileChooserParams?.mode == FileChooserParams.MODE_OPEN_MULTIPLE) {
                            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                        }
                    }
                } else {
                    fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                }

                try {
                    filePickerLauncher.launch(intent)
                } catch (e: Exception) {
                    fileChooserCallback?.onReceiveValue(null)
                    fileChooserCallback = null
                    android.widget.Toast.makeText(
                        this@MainActivity,
                        "Could not open the Android file picker: ${e.message ?: "unknown error"}",
                        android.widget.Toast.LENGTH_LONG
                    ).show()
                    return false
                }
                return true
            }
        }

        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            loadsImagesAutomatically = true
            useWideViewPort = true
            loadWithOverviewMode = true
            mediaPlaybackRequiresUserGesture = false
            cacheMode = WebSettings.LOAD_DEFAULT
        }

        // Expose Native Android Bridge to JavaScript
        webView.addJavascriptInterface(AUREMAndroidBridge(this), "AUREMNative")

        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }
}
